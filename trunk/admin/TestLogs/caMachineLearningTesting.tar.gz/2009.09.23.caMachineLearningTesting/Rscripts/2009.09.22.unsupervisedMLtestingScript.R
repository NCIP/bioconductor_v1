library(MLInterfaces)

d<-read.delim("es2.txt")
d<-data.frame(d[2:80], row.names=d$ProbeID)
.distFuncFactory <- function(method) {
    function(x) {
        dist(x, method=method)
    }
}
d2<-data.frame(t(d))

#distanceMetric<-"euclidean"
#clusteringMethod = "average"
numberOfClusters=8

clusteringMethods<-c("average", "complete", "median", "single", "ward")
distanceMetrics<-c("euclidean", "manhattan", "maximum", "minkowski")


for(c in clusteringMethods){
clusteringMethod<-c	

for(m in distanceMetrics){
distanceMetric<-m
	
resultsFileName<-paste("R_hClust_linkage_", clusteringMethod, "_numberOfClusters_", numberOfClusters, "_distanceMetric_", distanceMetric, ".txt", sep="")

distFun <- .distFuncFactory(distanceMetric)
clusteringOutput <- MLearn(formula=formula("~."), data=d2, 
                              hclustI( distFun=distFun, cutParm=list(k=numberOfClusters) ), method=clusteringMethod)
silhouette <- clusteringOutput@silhouette
        sampleName      <- colnames( d )
        partition       <- as.integer( silhouette[,"cluster"] )
        neighbor        <- as.integer( silhouette[,"neighbor"] )
        silhouetteWidth <- silhouette[,"sil_width"]
silhouetteWidth<-format(round(silhouetteWidth,5))
silhouetteWidth<-gsub(' ','',silhouetteWidth)
sampleName<-gsub('X','',sampleName)
results<-data.frame(sampleName, partition, neighbor, silhouetteWidth) 
names(results)<-c("Sample Name", "Predicted Partition", "Neighboring Partition", "Silhouette Width")
write.table(results,file=resultsFileName,sep="\t",quote=F,row.names=F)
}
}



#KMeans
d<-read.delim("es2.txt")
d<-data.frame(d[2:80], row.names=d$ProbeID)
d2<-data.frame(t(d))

numberOfClusters=8

algorithms<-c("Forgy", "Hartigan-Wong", "Lloyd", "MacQueen")

for(a in algorithms){
algorithm<-a

resultsFileName<-paste("R_kMeans_linkage_", algorithm, "_numberOfClusters_", numberOfClusters, ".txt", sep="")
clusteringOutput <- MLearn(formula=formula("~."), data=d2, kmeansI, centers=numberOfClusters, algorithm=algorithm)
silhouette <- clusteringOutput@silhouette
        sampleName      <- colnames( d )
        partition       <- as.integer( silhouette[,"cluster"] )
        neighbor        <- as.integer( silhouette[,"neighbor"] )
        silhouetteWidth <- silhouette[,"sil_width"]
silhouetteWidth<-format(round(silhouetteWidth,5))
silhouetteWidth<-gsub(' ','',silhouetteWidth)
sampleName<-gsub('X','',sampleName)
results<-data.frame(sampleName, partition, neighbor, silhouetteWidth) 
names(results)<-c("Sample Name", "Predicted Partition", "Neighboring Partition", "Silhouette Width")
write.table(results,file=resultsFileName,sep="\t",quote=F,row.names=F)
}
