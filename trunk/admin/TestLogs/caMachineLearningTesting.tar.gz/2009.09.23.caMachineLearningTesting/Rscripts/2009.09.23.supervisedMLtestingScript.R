library(MLInterfaces)

d<-read.delim("es2.txt")
d<-data.frame(d[2:80], row.names=d$ProbeID)
anno<-read.delim("supervisedMLSampleAnnotation_2.0forR.txt")
sampleName<-as.character(anno$Sample)
isTrainingSample<-anno$TrainingSample
type<-anno$ObservedClassification
df<-data.frame(t(d))
df[,"type"] <- type
trainingSamples <- which(isTrainingSample)

# Develop a classifier for 'type' based on all other data.
formula <- as.formula( paste("type", "~", ".", sep="") )


#KNearest Neighbors
numberOfNeighbors<-2
minimumVote<-1

resultsFileName<-paste("R_kNN_minVote_", minimumVote, "_neighbors_", numberOfNeighbors, ".txt", sep="")
classifierOutput <- MLearn(formula=formula, data=df,
                               knnI(k=numberOfNeighbors, l=minimumVote),
                               trainingSamples)

observedClassification <- c( classifierOutput@testOutcomes, classifierOutput@trainOutcomes )
observedClassification <- observedClassification[ sampleName ]
observedClassification <- levels(type)[ observedClassification ]

predictedClassification <- c( testPredictions(classifierOutput), trainPredictions(classifierOutput) )
predictedClassification <- predictedClassification[ sampleName ]
predictedClassification <- levels(type)[ predictedClassification ]

results<-data.frame(sampleName, observedClassification, predictedClassification, as.character(isTrainingSample))
results$as.character.isTrainingSample.<-gsub('TRUE','true',results$as.character.isTrainingSample.)
results$as.character.isTrainingSample.<-gsub('FALSE','false',results$as.character.isTrainingSample.)
results$sampleName<-gsub('X','',results$sampleName)
results$sampleName<-format(results$sampleName)
names(results)<-c("Sample Name", "Observed Partition", "Predicted Partition", "Training Sample")
write.table(results, file=resultsFileName, sep="\t", quote=F, row.names=F)


#SupportVector

resultsFileName<-"R_supportVector.txt"

classifierOutput <- MLearn(formula=formula, data=df,
                               svmI,
                               trainingSamples)
			       
observedClassification <- c( classifierOutput@testOutcomes, classifierOutput@trainOutcomes )
observedClassification <- observedClassification[ sampleName ]
observedClassification <- levels(type)[ observedClassification ]
predictedClassification <- c( testPredictions(classifierOutput), trainPredictions(classifierOutput) )
predictedClassification <- predictedClassification[ sampleName ]
predictedClassification <- levels(type)[ predictedClassification ]
results<-data.frame(sampleName, observedClassification, predictedClassification, as.character(isTrainingSample))
results$as.character.isTrainingSample.<-gsub('TRUE','true',results$as.character.isTrainingSample.)
results$as.character.isTrainingSample.<-gsub('FALSE','false',results$as.character.isTrainingSample.)
results$sampleName<-gsub('X','',results$sampleName)
results$sampleName<-format(results$sampleName)
names(results)<-c("Sample Name", "Observed Partition", "Predicted Partition", "Training Sample")
write.table(results, file=resultsFileName, sep="\t", quote=F, row.names=F)


#Linear Discriminant Analysis
resultsFileName<-"R_linearDiscriminant.txt"
classifierOutput <- MLearn(formula=formula, data=df,
                               ldaI,
                               trainingSamples)
			       
observedClassification <- c( classifierOutput@testOutcomes, classifierOutput@trainOutcomes )
observedClassification <- observedClassification[ sampleName ]
observedClassification <- levels(type)[ observedClassification ]
predictedClassification <- c( testPredictions(classifierOutput), trainPredictions(classifierOutput) )
predictedClassification <- predictedClassification[ sampleName ]
predictedClassification <- levels(type)[ predictedClassification ]
results<-data.frame(sampleName, observedClassification, predictedClassification, as.character(isTrainingSample))
results$as.character.isTrainingSample.<-gsub('TRUE','true',results$as.character.isTrainingSample.)
results$as.character.isTrainingSample.<-gsub('FALSE','false',results$as.character.isTrainingSample.)
results$sampleName<-gsub('X','',results$sampleName)
results$sampleName<-format(results$sampleName)
names(results)<-c("Sample Name", "Observed Partition", "Predicted Partition", "Training Sample")
write.table(results, file=resultsFileName, sep="\t", quote=F, row.names=F)


#Diagonal Linear Discriminant Analysis
resultsFileName<-"R_diagLinDisc.txt"
classifierOutput <- MLearn(formula=formula, data=df,
                               dldaI,
                               trainingSamples)

observedClassification <- c( classifierOutput@testOutcomes, classifierOutput@trainOutcomes )
observedClassification <- observedClassification[ sampleName ]
observedClassification <- levels(type)[ observedClassification ]
predictedClassification <- c( testPredictions(classifierOutput), trainPredictions(classifierOutput) )
predictedClassification <- predictedClassification[ sampleName ]
predictedClassification <- levels(type)[ predictedClassification ]
results<-data.frame(sampleName, observedClassification, predictedClassification, as.character(isTrainingSample))
results$as.character.isTrainingSample.<-gsub('TRUE','true',results$as.character.isTrainingSample.)
results$as.character.isTrainingSample.<-gsub('FALSE','false',results$as.character.isTrainingSample.)
results$sampleName<-gsub('X','',results$sampleName)
results$sampleName<-format(results$sampleName)
names(results)<-c("Sample Name", "Observed Partition", "Predicted Partition", "Training Sample")
write.table(results, file=resultsFileName, sep="\t", quote=F, row.names=F)


#Naive Bayes
resultsFileName<-"R_naiveBayes.txt"
classifierOutput <- MLearn(formula=formula, data=df,
                               naiveBayesI,
                               trainingSamples)
			       
observedClassification <- c( classifierOutput@testOutcomes, classifierOutput@trainOutcomes )
observedClassification <- observedClassification[ sampleName ]
observedClassification <- levels(type)[ observedClassification ]
predictedClassification <- c( testPredictions(classifierOutput), trainPredictions(classifierOutput) )
predictedClassification <- predictedClassification[ sampleName ]
predictedClassification <- levels(type)[ predictedClassification ]
results<-data.frame(sampleName, observedClassification, predictedClassification, as.character(isTrainingSample))
results$as.character.isTrainingSample.<-gsub('TRUE','true',results$as.character.isTrainingSample.)
results$as.character.isTrainingSample.<-gsub('FALSE','false',results$as.character.isTrainingSample.)
results$sampleName<-gsub('X','',results$sampleName)
results$sampleName<-format(results$sampleName)
names(results)<-c("Sample Name", "Observed Partition", "Predicted Partition", "Training Sample")
write.table(results, file=resultsFileName, sep="\t", quote=F, row.names=F)





