#GO
library(GSEABase)	

		d<-read.delim("probesForTesting_v1.2.txt", skip=1)
		reporterName<-as.character(d$Reporter.Name)
		#test parameters
		annotation<-"hgu95av2"
		#ontology<-"CC"
		minimumGenesPerGeneSet<-3

		#
		# Check for and load the specified annotation package if necessary.
		#
		.requireAnnotation <- function(annotation) {
		if (require(annotate::annPkgName(annotation), character.only=TRUE) != TRUE) {
			tryCatch({
			source('http://bioconductor.org/biocLite.R')
			biocLite(annotate::annPkgName(annotation))
			if (require(annotate::annPkgName(annotation), character.only=TRUE) != TRUE)
			stop("unknown annotation:", annotation)
			}, error=function(err) {
			stop("could not access annotation:", annotation,
				"\n  reason:", conditionMessage(err))
			})
		}
		}	
			.requireAnnotation(annotation)
		
		ontologies<-c("MF","CC","BP")
		#ontologies<-c("CC")
		
		for(o in ontologies){
		ontology<-o
		tCoefficient<-d$t	
		resultsFileName<-paste("R_continuous_", annotation, "_minGene_", minimumGenesPerGeneSet, "_", ontology, ".txt", sep="")
		map <- getAnnMap(map="GO", chip=annotation, load=TRUE)
		tbl <- toTable( map[reporterName] )
		lst <- with(tbl[tbl[["Ontology"]] == ontology,],
				split(probe_id, go_id))
			lst <- lst[ sapply(lst, is.character) ]      # filter out NAs
			lst <- lapply(lst, unique)  # remove duplicate probe ids
			lst <- lst[ sapply(lst, length) >= minimumGenesPerGeneSet ]
			gsc <- GeneSetCollection(mapply(function(geneId, id) {
				GeneSet(geneId, geneIdType=AnnotationIdentifier(annotation),
					collectionType=GOCollection(id, ontology=ontology),
					setName=id)
			}, lst, names(lst)))
		# Build the incidence matrix.  Select only those tCoefficients for
		# genes that remain as column names of the incidence matrix.
		Am <- incidence(gsc)
		tCoefficient <- tCoefficient[ match( reporterName, colnames(Am), nomatch=0 ) ]
		# Execute the test.  For a GeneSet of size n, sum(tstat)/sqrt(n)
		# is approximately normally distributed with mean 0 and variance 1.
		tA    <- as.vector(Am %*% tCoefficient)
		tAadj <- tA/sqrt(rowSums(Am))
		names(tA) <- names(tAadj) <- rownames(Am)
		pValue <- pnorm( abs(tAadj), lower.tail=FALSE )
		geneSetMembers        <- lapply(gsc, geneIds)
		names(geneSetMembers) <- names(gsc)
		#generate results
		gsm<-as.matrix(geneSetMembers)
gsm<-data.frame(rownames(gsm), as.character(gsm))
names(gsm)<-c("GeneSetID","probes")
gsm$probes<-gsub('c\\(','',gsm$probes)
gsm$probes<-gsub('\\)','',gsm$probes)
gsm$probes<-gsub('\\"','',gsm$probes)
gsm$probes<-gsub('\\,','',gsm$probes)
res<-data.frame(names(pValue), format(round(pValue,5)))
names(res)<-c("GeneSetID", "p-value")
results<-merge(res, gsm, by.x="GeneSetID", by.y="GeneSetID")
write.table(results, file=resultsFileName, sep="\t", quote=F, row.names=F)			
}
		

#KEGG
library(GSEABase)	
		resultsFileName<-paste("R_continuous_", annotation, "_minGene_", minimumGenesPerGeneSet, "_KEGG.txt", sep="")
		tCoefficient<-d$t
		# Map reporterNames to KEGG sets via annotation.
		map <- getAnnMap(map="PATH", chip=annotation, load=TRUE)

		lst <- reverseSplit(as.list( map[reporterName] ))
		lst <- lst[ sapply(lst, is.character) ] # filter out NAs
		lst <- lapply(lst, unique)      # remove duplicate probe ids
		lst <- lst[ sapply( lst, length ) >= minimumGenesPerGeneSet ]
		gsc <- GeneSetCollection(mapply(function(geneId, id) {
			    GeneSet(geneId, geneIdType=AnnotationIdentifier(annotation),
				collectionType=KEGGCollection(id),
				setName=id)
		       }, lst, names(lst)))

		# Filter out GeneSets with fewer than minimumGenesPerGeneSet genes.
		if (length(gsc) == 0) 
		    stop("No GeneSets were found with greater than 'minimumGenesPerGeneSet' genes.")

		# Build the incidence matrix.  Select only those tCoefficients for
		# genes that remain as column names of the incidence matrix.
		Am <- incidence(gsc)
		tCoefficient <- tCoefficient[ match( reporterName, colnames(Am), nomatch=0 ) ]

		# Execute the test.  For a GeneSet of size n, sum(tstat)/sqrt(n)
		# is approximately normally distributed with mean 0 and variance 1.
		tA    <- as.vector(Am %*% tCoefficient)
		tAadj <- tA/sqrt(rowSums(Am))
		names(tA) <- names(tAadj) <- rownames(Am)
		pValue <- pnorm( abs(tAadj), lower.tail=FALSE )	
		geneSetMembers        <- lapply(gsc, geneIds)
		names(geneSetMembers) <- names(gsc)
		#generate results
gsm<-as.matrix(geneSetMembers)
gsm<-data.frame(rownames(gsm), as.character(gsm))
names(gsm)<-c("GeneSetID","probes")
gsm$probes<-gsub('c\\(','',gsm$probes)
gsm$probes<-gsub('\\)','',gsm$probes)
gsm$probes<-gsub('\\"','',gsm$probes)
gsm$probes<-gsub('\\,','',gsm$probes)
res<-data.frame(names(pValue), format(round(pValue,5)))
names(res)<-c("GeneSetID", "p-value")
results<-merge(res, gsm, by.x="GeneSetID", by.y="GeneSetID")
write.table(results, file=resultsFileName, sep="\t", quote=F, row.names=F)		

		
#PFAM

minimumGenes<-c(3,5,10)
for(m in minimumGenes){

minimumGenesPerGeneSet<-m

		resultsFileName<-paste("R_continuous_", annotation, "_minGene_", minimumGenesPerGeneSet, "_PFAM.txt", sep="")
		tCoefficient<-d$t
			
		# Map reporterNames to PFAM sets via annotation.
		map <- getAnnMap(map="PFAM", annotation)[reporterName]

		lst <- reverseSplit(eapply(map, as.vector))
		lst <- lst[ sapply(lst, is.character) ]      # filter out NAs
		lst <- lapply(lst, unique)      # remove duplicate probe ids
		lst <- lst[ sapply( lst, length ) >= minimumGenesPerGeneSet ]
		gsc <- GeneSetCollection(mapply(function(geneId, id) {
			    GeneSet(geneId, geneIdType=AnnotationIdentifier(annotation),
				collectionType=PfamCollection(id),
				setName=id)
		       }, lst, names(lst)))

		if (length(gsc) == 0)
		    stop("No GeneSets were found with greater than 'minimumGenesPerGeneSet' genes.")

		# Build the incidence matrix.  Select only those tCoefficients for
		# genes that remain as column names of the incidence matrix.
		Am <- incidence(gsc)
		tCoefficient <- tCoefficient[ match( reporterName, colnames(Am), nomatch=0 ) ]
		
		# Execute the test.  For a GeneSet of size n, sum(tstat)/sqrt(n)
		# is approximately normally distributed with mean 0 and variance 1.
		tA    <- as.vector(Am %*% tCoefficient)
		tAadj <- tA/sqrt(rowSums(Am))
		names(tA) <- names(tAadj) <- rownames(Am)
		pValue <- pnorm( abs(tAadj), lower.tail=FALSE )
		geneSetMembers        <- lapply(gsc, geneIds)
		names(geneSetMembers) <- names(gsc)
				#generate results
		gsm<-as.matrix(geneSetMembers)
gsm<-data.frame(rownames(gsm), as.character(gsm))
names(gsm)<-c("GeneSetID","probes")
gsm$probes<-gsub('c\\(','',gsm$probes)
gsm$probes<-gsub('\\)','',gsm$probes)
gsm$probes<-gsub('\\"','',gsm$probes)
gsm$probes<-gsub('\\,','',gsm$probes)
res<-data.frame(names(pValue), format(round(pValue,5)))
names(res)<-c("GeneSetID", "p-value")
results<-merge(res, gsm, by.x="GeneSetID", by.y="GeneSetID")
write.table(results, file=resultsFileName, sep="\t", quote=F, row.names=F)			
}

