library(GSEABase)
library(GOstats)

d<-read.delim("probesForTesting_v1.2.txt", skip=1)
annotation<-"hgu95av2"
discretePValue<-"0.05"

#
# Check for and load the specified annotation package if necessary.
#
.requireAnnotation <- function(annotation) {
if (require(annotate::annPkgName(annotation), character.only=TRUE) != TRUE) {
tryCatch({
source('http://bioconductor.org/biocLite.R')
biocLite(annotate::annPkgName(annotation))
if (require(annotate::annPkgName(annotation), character.only=TRUE) != TRUE)
stop("unknown annotation:", annotation)
}, error=function(err) {
stop("could not access annotation:", annotation,
"\n  reason:", conditionMessage(err))
})
}
}
.requireAnnotation(annotation)


reporterName<-as.character(d$Reporter.Name)
universe<-reporterName
selected<-subset(d, d$p.value <= discretePValue)
selected<-as.character(selected$Reporter.Name)

map <- getAnnMap("ENTREZID", annotation)
universeENTREZIds <- unlist( mget(universe, map, ifnotfound=NA), use.names=FALSE )
universeENTREZIds <- unique( universeENTREZIds[!is.na(universeENTREZIds)] )
selectedMap <- mget(selected, map, ifnotfound=NA)
selectedENTREZIds <- unlist( selectedMap, use.names=FALSE )
selectedENTREZIds <- unique( selectedENTREZIds[!is.na(selectedENTREZIds)] )

directions<-c("over", "under")
for (d in directions) {

#direction<-"over"
direction<-d

ontologies<-c("BP", "CC", "MF")
for (o in ontologies){

#ontology<-"CC"
ontology<-o

outputFileName<-paste("R_discrete_", annotation, "_pVal_", discretePValue, "_dir_", direction, "_", ontology, ".txt", sep="")



params = new("GOHyperGParams",
geneIds=selectedENTREZIds,
universeGeneIds=universeENTREZIds,
annotation=annotation,
ontology=ontology,
pvalueCutoff=1.0,            # return all results
conditional=FALSE,
testDirection=direction
)
        # Execute the test.
        res <- hyperGTest(params)   # returns instance of HyperGResult-class in the Category package
        # Map ENTREZ IDs back to reporter names.
        rselectedMap   <- revmap(selectedMap)
        geneSetMembers <- lapply(geneIdsByCategory(res), function(i, x) unique(unlist(x[i], use.names=FALSE)), x=rselectedMap)
results<-data.frame(sigCategories(res, p=1.01), pvalues(res))
results<-data.frame(sigCategories(res, p=1.01), format(round(pvalues(res),5)))

gsm<-as.matrix(geneSetMembers)
gsm<-data.frame(rownames(gsm), as.character(gsm))
names(gsm)<-c("GeneSetID","probes")
gsm$probes<-gsub('c\\(','',gsm$probes)
gsm$probes<-gsub('\\)','',gsm$probes)
gsm$probes<-gsub('\\"','',gsm$probes)
gsm$probes<-gsub('\\,','',gsm$probes)
names(results)<-c("GeneSetID", "p-value")
results2<-merge(results, gsm, by.x="GeneSetID", by.y="GeneSetID")
results2$probes<-gsub('NULL','',results2$probes)
results2<-results2[order(results2$"p-value"),]
write.table(results2, file=outputFileName,sep="\t",quote=F, row.names=F)

}


#KEGG

ontology<-"KEGG"
outputFileName<-paste("R_discrete_", annotation, "_pVal_", discretePValue, "_dir_", direction, "_", ontology, ".txt", sep="")

# Prepare parameters object for analysis.
params = new("KEGGHyperGParams",
                     geneIds=selectedENTREZIds,
                     universeGeneIds=universeENTREZIds,
                     annotation=annotation,
                     pvalueCutoff=1.0,              # return all results
                     testDirection=direction
                    )

# Execute the test.
res <- hyperGTest(params)   # returns instance of HyperGResult-class in the Category package
rselectedMap   <- revmap(selectedMap)
geneSetMembers <- lapply(geneIdsByCategory(res), function(i, x) unique(unlist(x[i], use.names=FALSE)), x=rselectedMap)

results<-data.frame(sigCategories(res, p=1.01), pvalues(res))
results<-data.frame(sigCategories(res, p=1.01), format(round(pvalues(res),5)))

gsm<-as.matrix(geneSetMembers)
gsm<-data.frame(rownames(gsm), as.character(gsm))
names(gsm)<-c("GeneSetID","probes")
gsm$probes<-gsub('c\\(','',gsm$probes)
gsm$probes<-gsub('\\)','',gsm$probes)
gsm$probes<-gsub('\\"','',gsm$probes)
gsm$probes<-gsub('\\,','',gsm$probes)
names(results)<-c("GeneSetID", "p-value")
results2<-merge(results, gsm, by.x="GeneSetID", by.y="GeneSetID")
results2$probes<-gsub('NULL','',results2$probes)
results2<-results2[order(results2$"p-value"),]
write.table(results2, file=outputFileName,sep="\t",quote=F, row.names=F)


#PFAM

ontology<-"PFAM"
outputFileName<-paste("R_discrete_", annotation, "_pVal_", discretePValue, "_dir_", direction, "_", ontology, ".txt", sep="")

# Prepare parameters object for analysis.
params = new("PFAMHyperGParams",
                     geneIds=selectedENTREZIds,
                     universeGeneIds=universeENTREZIds,
                     annotation=annotation,
                     pvalueCutoff=1.0,            # return all results
                     testDirection=direction
                    )

# Execute the test.
res <- hyperGTest(params)   # returns instance of HyperGResult-class in the Category package

# Map ENTREZ IDs back to reporter names.
rselectedMap   <- revmap(selectedMap)
geneSetMembers <- lapply(geneIdsByCategory(res), function(i, x) unique(unlist(x[i], use.names=FALSE)), x=rselectedMap)

results<-data.frame(sigCategories(res, p=1.01), pvalues(res))
results<-data.frame(sigCategories(res, p=1.01), format(round(pvalues(res),5)))

gsm<-as.matrix(geneSetMembers)
gsm<-data.frame(rownames(gsm), as.character(gsm))
names(gsm)<-c("GeneSetID","probes")
gsm$probes<-gsub('c\\(','',gsm$probes)
gsm$probes<-gsub('\\)','',gsm$probes)
gsm$probes<-gsub('\\"','',gsm$probes)
gsm$probes<-gsub('\\,','',gsm$probes)
names(results)<-c("GeneSetID", "p-value")
results2<-merge(results, gsm, by.x="GeneSetID", by.y="GeneSetID")
results2$probes<-gsub('NULL','',results2$probes)
results2<-results2[order(results2$"p-value"),]
write.table(results2, file=outputFileName,sep="\t",quote=F, row.names=F)

}